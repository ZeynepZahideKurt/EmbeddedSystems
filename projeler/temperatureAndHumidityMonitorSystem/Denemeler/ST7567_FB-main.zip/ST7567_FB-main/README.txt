This is fast SPI library for ST7567 128x64 display.

Supports both hardware and software SPI
Uses 128*8 bytes of RAM as frame buffer memory. Most common graphics primitives implemented with 17-level dithering
Some examples require PropFonts or RREFont library
